package runapplication;
import java.util.Scanner;


interface ICricket {
    String getBatsmanName();
    String getStadium();
    int getRunsScored();
}


class Cricket {
    private String batsmanName;
    private String stadium;
    private int runsScored;

    public Cricket(String batsmanName, String stadium, int runsScored) {
        this.batsmanName = batsmanName;
        this.stadium = stadium;
        this.runsScored = runsScored;
    }

    public String getBatsmanName() {
        return batsmanName;
    }

    public String getStadium() {
        return stadium;
    }

    public int getRunsScored() {
        return runsScored;
    }
}


class CricketRunsScored extends Cricket implements ICricket {
    public CricketRunsScored(String batsmanName, String stadium, int runsScored) {
        super(batsmanName, stadium, runsScored);
    }

    public void printReport() {
        System.out.println("\nBATSMAN RUNS SCORED REPORT ");
        System.out.println("********************");
        System.out.println("CRICKET PLAYER: " + getBatsmanName());
        System.out.println("STADIUM: " + getStadium());
        System.out.println("TOTAL RUNS SCORED: " + getRunsScored());
    }
}


public class RunApplication {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        
        System.out.print("The cricketer name: ");
        String name = sc.nextLine();

        System.out.print("Enter the stadium: ");
        String stadium = sc.nextLine();

        System.out.print("Enter the total runs scored by " + name + " at " + stadium + ": ");
        int runs = sc.nextInt();

       
        CricketRunsScored player = new CricketRunsScored(name, stadium, runs);

     
        player.printReport();

        sc.close();
    }
}



