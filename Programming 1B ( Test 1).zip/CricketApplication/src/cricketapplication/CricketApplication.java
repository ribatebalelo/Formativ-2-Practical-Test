package cricketapplication;

import java.util.Scanner;

public class CricketApplication {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

     
        String[] batsmen = {"Jacques Kallis", "Hashim Amla", "AB De Villiers"};
        String[] stadiums = {"Kingsmead", "St Georges", "Wanderers"};

        int[][] runs = new int[stadiums.length][batsmen.length];

        System.out.println("CRICKET APPLICATION");
        System.out.println("-------------------------------------------------------------");
        for (int i = 0; i < stadiums.length; i++) {
            for (int j = 0; j < batsmen.length; j++) {
                System.out.print("Enter the number of runs scored by " + batsmen[j] +
                        " at " + stadiums[i] + ": ");
                runs[i][j] = sc.nextInt();
            }
            System.out.println();
        }

        System.out.println("-------------------------------------------------------------");
        System.out.println(" RUNS SCORED REPORT");
        System.out.println("-------------------------------------------------------------");
        for (int i = 0; i < stadiums.length; i++) {
            for (int j = 0; j < batsmen.length; j++) {
                System.out.println(batsmen[j] + " runs scored at " + stadiums[i] + ": " + runs[i][j]);
            }
            System.out.println();
        }

        
        int[] totalPerStadium = new int[stadiums.length];
        for (int i = 0; i < stadiums.length; i++) {
            int sum = 0;
            for (int j = 0; j < batsmen.length; j++) {
                sum += runs[i][j];
            }
            totalPerStadium[i] = sum;
        }

        System.out.println("-------------------------------------------------------------");
        System.out.println("TOTAL RUNS AT STADIUMS");
        System.out.println("-------------------------------------------------------------");
        for (int i = 0; i < stadiums.length; i++) {
            System.out.println(stadiums[i] + ": " + totalPerStadium[i]);
        }

  
        int maxRuns = totalPerStadium[0];
        String maxStadium = stadiums[0];
        for (int i = 1; i < stadiums.length; i++) {
            if (totalPerStadium[i] > maxRuns) {
                maxRuns = totalPerStadium[i];
                maxStadium = stadiums[i];
            }
        }
        System.out.println("\nSTADIUM WITH THE MOST RUNS: " + maxStadium);

        sc.close();
    }
}
